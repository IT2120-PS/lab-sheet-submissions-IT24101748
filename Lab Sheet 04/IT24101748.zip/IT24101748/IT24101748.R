setwd("C:\\Users\\ryasa\\Desktop\\IT24101748")

branch_data <- read.table("Exercise.txt", header = TRUE)

str(branch_data)


boxplot(branch_data$Sales_X1, main="Sales (X1)")
fivenum(branch_data$Advertising_X2) 
IQR(branch_data$Advertising_X2)

iqr_outliers <- function(x) {
  q1 <- quantile(x, 0.25, type=2); q3 <- quantile(x, 0.75, type=2)
  i <- IQR(x); lower <- q1 - 1.5*i; upper <- q3 + 1.5*i
  list(bounds=c(lower=lower, upper=upper), outliers=x[x<lower | x>upper])
}
iqr_outliers(branch_data$Years_X3)

