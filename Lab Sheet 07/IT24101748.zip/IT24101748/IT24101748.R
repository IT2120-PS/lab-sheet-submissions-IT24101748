setwd("C://Users//ryasa//Desktop//IT24101748")

# Q1
punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

# Q2
pexp(2, rate = 1/3, lower.tail = TRUE)

# Q3(i)
# Upper tail above 130
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

# Q3(ii)
# 95th percentile (quantile)
qnorm(0.95, mean = 100, sd = 15)


